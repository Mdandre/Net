﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LabLoginWEBB
{
    public partial class Login : System.Web.UI.Page
    {
  
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        
      
        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtClave.Text=="Admin" && txtUsuario.Text == "Admin")
            {
                Page.Response.Write("Ingreso OK");
            }
            else
            {
                Page.Response.Write("Usuario y/o contraseña incorrecta");
            }
        }
    }
}