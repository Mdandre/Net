﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clases;

namespace LabClases2
{
    class Program
    {
        static void Main(string[] args)
        {
            B b = new B();
            A a = new A();
            a.F();
            b.F();
            a.G();
            b.G();

            Console.ReadKey();
        }
    }
}
